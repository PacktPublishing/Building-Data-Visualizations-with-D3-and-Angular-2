d3.select('body')
  .append('h1')
  .text('Let\'s build a bar graph!');