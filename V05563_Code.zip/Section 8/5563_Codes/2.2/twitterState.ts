import { Tweet } from './tweet';

export class TwitterState {
  tweets: Tweet[];
}
